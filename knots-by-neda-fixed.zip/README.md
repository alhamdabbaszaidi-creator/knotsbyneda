# Knots By Neda — fixed auth + PayPal + orders

## 1. Upload these files to your Vercel project
- index.html
- api/_shared.js
- api/paypal-create-order.js
- api/paypal-capture-order.js
- api/manual-submit.js
- package.json

## 2. Supabase
Run `supabase-orders.sql` in Supabase SQL Editor.

Authentication:
- Google provider must be enabled.
- Add your Vercel production URL to Supabase Authentication > URL Configuration > Redirect URLs.
  Example: https://your-site.vercel.app/**

The same Supabase project is what makes a customer's account and orders follow them when they visit the new site.

## 3. Vercel environment variables
Add every variable from `.env.example`.
IMPORTANT: SUPABASE_SERVICE_ROLE_KEY and PAYPAL_CLIENT_SECRET are server secrets. Never put them in index.html.

## 4. PayPal
Create/use a PayPal app in the PayPal developer dashboard.
For testing, use:
PAYPAL_ENV=sandbox
and the sandbox client ID + sandbox secret.
When ready for real payments, switch to:
PAYPAL_ENV=live
and use the live client ID + live secret.

## 5. Email
The API uses Resend to email paid orders to snazaidi5@gmail.com.
You need a Resend API key and a verified sending domain/address for ORDER_FROM_EMAIL.

## Why the old login appeared to disappear
Your old `handleAuthNavClick()` explicitly called `supabase.auth.signOut()` whenever `currentUser` existed. So clicking the button while signed in immediately signed the user out. The fixed version asks for confirmation instead.

The old code also queried every order without filtering it in the browser. The new database RLS policy limits each signed-in user to their own orders, while the server creates orders securely.
