const { getUser, priceFor, json } = require("./_shared");

async function paypalAccessToken() {
  const credentials = Buffer.from(`${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`).toString("base64");
  const base = process.env.PAYPAL_ENV === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com";
  const r = await fetch(`${base}/v1/oauth2/token`, {
    method:"POST",
    headers:{Authorization:`Basic ${credentials}`,"Content-Type":"application/x-www-form-urlencoded"},
    body:"grant_type=client_credentials"
  });
  const d=await r.json();
  if(!r.ok) throw new Error(d.error_description || "PayPal authentication failed.");
  return {token:d.access_token,base};
}
module.exports = async (req,res)=>{
  if(req.method!=="POST") return json(res,405,{error:"Method not allowed"});
  try{
    await getUser(req);
    const {product,quantity}=req.body||{};
    const total=priceFor(product,quantity);
    const {token,base}=await paypalAccessToken();
    const r=await fetch(`${base}/v2/checkout/orders`,{
      method:"POST",
      headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},
      body:JSON.stringify({
        intent:"CAPTURE",
        purchase_units:[{amount:{currency_code:"USD",value:total.toFixed(2)},description:product}]
      })
    });
    const d=await r.json();
    if(!r.ok) throw new Error(d.message || "Could not create PayPal order.");
    return json(res,200,{id:d.id,total});
  }catch(e){return json(res,400,{error:e.message})}
};
