const { getUser, priceFor, supabaseAdmin, json } = require("./_shared");

module.exports = async (req,res)=>{
  if(req.method!=="POST") return json(res,405,{error:"Method not allowed"});
  try{
    const user=await getUser(req);
    const {method,reference,order}=req.body||{};
    if(!["zelle","cashapp"].includes(method)) throw new Error("Invalid payment method.");
    if(!reference?.trim()) throw new Error("Payment reference is required.");
    const total=priceFor(order.product,order.quantity);
    const admin=supabaseAdmin();
    const row={user_id:user.id,product:order.product,color:order.color,size:order.size,quantity:Number(order.quantity),notes:order.notes||"",customer_name:order.customerName,customer_email:order.customerEmail,total,payment_method:method==="zelle"?"Zelle":"CashApp",payment_reference:reference.trim(),status:"pending_manual_verification"};
    const {error}=await admin.from("orders").insert(row);
    if(error) throw new Error(error.message);
    if(process.env.RESEND_API_KEY){
      const text=`NEW ${row.payment_method.toUpperCase()} ORDER — NEEDS VERIFICATION\n\nCustomer: ${row.customer_name}\nEmail: ${row.customer_email}\nProduct: ${row.product}\nColor: ${row.color}\nSize: ${row.size}\nQuantity: ${row.quantity}\nTotal: $${total.toFixed(2)}\nReference: ${row.payment_reference}\nNotes: ${row.notes || "(none)"}`;
      await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Authorization":`Bearer ${process.env.RESEND_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({from:process.env.ORDER_FROM_EMAIL,to:["snazaidi5@gmail.com"],subject:`New ${row.payment_method} order — verification needed`,text})});
    }
    return json(res,200,{success:true,total});
  }catch(e){return json(res,400,{error:e.message})}
};
