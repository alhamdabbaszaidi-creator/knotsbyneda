const { createClient } = require("@supabase/supabase-js");

const PRODUCTS = {
  "Macrame Mirror": 45,
  "Macrame Keychains": 15,
  "Handmade Handbag": 55,
  "Macrame Chandeliers": 70
};

function supabaseAdmin() {
  return createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
}
async function getUser(req) {
  const auth = req.headers.authorization || "";
  if (!auth.startsWith("Bearer ")) throw new Error("Missing login session.");
  const token = auth.slice(7);
  const admin = supabaseAdmin();
  const { data, error } = await admin.auth.getUser(token);
  if (error || !data.user) throw new Error("Your login session is invalid or expired.");
  return data.user;
}
function priceFor(product, quantity) {
  const unit = PRODUCTS[product];
  const qty = Number(quantity);
  if (!unit || !Number.isInteger(qty) || qty < 1 || qty > 4) throw new Error("Invalid product or quantity.");
  return Number((unit * qty).toFixed(2));
}
function json(res,status,body){res.status(status).setHeader("Content-Type","application/json");res.end(JSON.stringify(body));}

module.exports = { PRODUCTS, supabaseAdmin, getUser, priceFor, json };
