const { getUser, priceFor, supabaseAdmin, json } = require("./_shared");

async function paypalAccessToken() {
  const credentials = Buffer.from(`${process.env.PAYPAL_CLIENT_ID}:${process.env.PAYPAL_CLIENT_SECRET}`).toString("base64");
  const base = process.env.PAYPAL_ENV === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com";
  const r = await fetch(`${base}/v1/oauth2/token`, {
    method:"POST",headers:{Authorization:`Basic ${credentials}`,"Content-Type":"application/x-www-form-urlencoded"},
    body:"grant_type=client_credentials"
  });
  const d=await r.json();
  if(!r.ok) throw new Error(d.error_description || "PayPal authentication failed.");
  return {token:d.access_token,base};
}
module.exports = async (req,res)=>{
  if(req.method!=="POST") return json(res,405,{error:"Method not allowed"});
  try{
    const user=await getUser(req);
    const {paypalOrderId,order}=req.body||{};
    if(!paypalOrderId||!order) throw new Error("Missing PayPal order information.");
    const total=priceFor(order.product,order.quantity);
    const {token,base}=await paypalAccessToken();
    const r=await fetch(`${base}/v2/checkout/orders/${encodeURIComponent(paypalOrderId)}/capture`,{
      method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"}
    });
    const capture=await r.json();
    if(!r.ok) throw new Error(capture.message || "PayPal capture failed.");
    const paidUnit=capture.purchase_units?.[0];
    const captured=paidUnit?.payments?.captures?.[0];
    if(capture.status!=="COMPLETED" || captured?.status!=="COMPLETED") throw new Error("PayPal did not report a completed payment.");
    const paidAmount=Number(captured.amount?.value);
    if(Math.abs(paidAmount-total)>0.001 || captured.amount?.currency_code!=="USD") throw new Error("PayPal amount did not match the order.");

    const admin=supabaseAdmin();
    const row={user_id:user.id,product:order.product,color:order.color,size:order.size,quantity:Number(order.quantity),notes:order.notes||"",customer_name:order.customerName,customer_email:order.customerEmail,total,payment_method:"PayPal",payment_reference:paypalOrderId,status:"paid"};
    const {data,error}=await admin.from("orders").insert(row).select().single();
    if(error) throw new Error(error.message);
    await sendOrderEmail({user,row:data});
    return json(res,200,{success:true,total});
  }catch(e){return json(res,400,{error:e.message})}
};

async function sendOrderEmail({user,row}) {
  if(!process.env.RESEND_API_KEY) return;
  const text=`NEW PAID ORDER\n\nCustomer: ${row.customer_name}\nEmail: ${row.customer_email}\nAccount: ${user.email || user.id}\nProduct: ${row.product}\nColor: ${row.color}\nSize: ${row.size}\nQuantity: ${row.quantity}\nTotal: $${Number(row.total).toFixed(2)}\nPayment: ${row.payment_method}\nPayPal Order ID: ${row.payment_reference}\nNotes: ${row.notes || "(none)"}`;
  await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Authorization":`Bearer ${process.env.RESEND_API_KEY}`,"Content-Type":"application/json"},body:JSON.stringify({from:process.env.ORDER_FROM_EMAIL,to:["snazaidi5@gmail.com"],subject:`New paid order — ${row.product}`,text})});
}
